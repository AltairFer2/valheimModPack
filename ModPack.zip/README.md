Este modpack está pensado para una serie de speed run que se puede ver en Twitch en cualquiera de los siguientes canales:

https://www.twitch.tv/mitsurugicm
https://www.twitch.tv/altairfernando

De igual manera, si estás viendo esto después del 2024, puedes encontrar el contenido resubido en los siguientes canales de youtube:

<a href="https://www.youtube.com/@MitsurugiCM"><img src="https://www.google.com/imgres?q=mitsurugicm&imgurl=https%3A%2F%2Fstatic-cdn.jtvnw.net%2Fjtv_user_pictures%2Fb18581ad-9a6f-4b24-95fd-09cd1e1c44ce-profile_image-300x300.png&imgrefurl=https%3A%2F%2Fwww.twitch.tv%2Fmitsurugicm&docid=NCku_8oVz5YeVM&tbnid=OZgyFxS-JSs7GM&vet=12ahUKEwi5y_XoxeaFAxWp5MkDHYPnBcEQM3oECBwQAA..i&w=300&h=300&hcb=2&itg=1&ved=2ahUKEwi5y_XoxeaFAxWp5MkDHYPnBcEQM3oECBwQAA" alt="Mitsu se la come"></a>

<a href="https://www.youtube.com/channel/UC2EpEjMF_hy_WU60NSQXFxg"><img src="https://pbs.twimg.com/profile_images/1745620758104006656/9NyVSFY0_400x400.png" alt="Mitsu se la come"></a>

Gracias por tu apoyo!!!!

Recuerden que Mitsu se la come
