Este modpack está pensado para una serie de speed run que se puede ver en Twitch en cualquiera de los siguientes canales:

https://www.twitch.tv/mitsurugicm
https://www.twitch.tv/altairfernando

De igual manera, si estás viendo esto después del 2024, puedes encontrar el contenido resubido en los siguientes canales de youtube:

https://www.youtube.com/@MitsurugiCM
https://www.youtube.com/channel/UC2EpEjMF_hy_WU60NSQXFxg

Gracias por tu apoyo!!!!
