- Se eliminaron mods que daban una dificultad imposible al juego.
- Se han agregado mods que permiten hacer uso de objetos en los cofres
  dentro de las mesas de creación, forja, etc.
- Se removieron mods que agregaban monstruos en el óceano debido a que no representaban una amenaza real.
- Se eliminó Wacky Database debido a un problema que generaba la primera vez que se implementaba y forzaba a realizar demasiadas modificaciones complicadas arruinando la experiencia del jugador.
- Se quita el mod de better progression debido a un fallo al encimar el inventario.
- Se quitó hardbosses porque había un bug al eliminar a Mother.
- Se Obvia que Mitsu se la come.

<div style="text-align: center;">
    <a href="https://www.youtube.com/@MitsurugiCM">
        <img src="https://static-cdn.jtvnw.net/jtv_user_pictures/b18581ad-9a6f-4b24-95fd-09cd1e1c44ce-profile_image-300x300.png" alt="Mitsu se la come" style="width: 50%; height: auto;">
    </a>
</div>

![Captura de pantalla de Mitsu enojado por cambiar mods](https://static1-es.millenium.gg/articles/5/33/43/5/@/155145-yagluth-boss-5-valheim-orig-2-article_cover_bd-1.jpg)
